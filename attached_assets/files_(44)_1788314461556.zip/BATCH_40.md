# Batch 40 — two tests that broke when you used a feature

Two files: `tests/test_stage1.py` and `tests/test_stage6_longevity.py`.

No app change. `bootstrap.py` and `rebuild.sh` from batch 39 are correct and in.

## What was wrong

Both failures came from setting a manager's growth to 10% — a legitimate use of
the budget page. **A suite that goes red when somebody uses a feature teaches
everyone to ignore it**, which is worse than having no suite.

**`test_active_growth_percentage_is_reported`** asserted a literal `0.0750`.

**`test_budget_is_forecast_plus_growth`** was subtler and your agent's read of it
was close but not quite right. It already read the rate from `growth_rate` — but
it summed the WHOLE YEAR and compared that against the GLOBAL rate. That only
holds while every manager is on it. With one override in play the aggregate
matched no single rate:

```
276,789.23 / 3,542,779.20 = 7.81%     neither 7.5% nor 10%
```

## The fix

**Row by row, at each row's own rate.** `v_budget_quarter` already carries the
applied `growth_pct` per row and leaves it NULL where a quarter mixes rates.
Those rows are skipped rather than guessed at, and the identity
`total = forecast + growth target` is asserted for every row regardless, since
that holds whatever the rate.

It also asserts that at least one quarter was checkable, so the test cannot
quietly pass by skipping everything.

**The second reads the resolved rate instead of restating it.** The response says
which level of the hierarchy supplied the figure — global, manager, or
manager_quarter — so the test asks for that level and checks the number agrees.
What matters is not which number it is but that the page reports the same rate
the system resolved, and names where it came from.

## Checked

Both files parse. `scalar()` and `rows()` are defined in each file that uses
them, and `conn` is already a fixture in both. The arithmetic is traced against
the figures from your own traceback.

I could not run the suite — no database in my environment.

## Install

Replace both, run the suite, commit and push. No restart, no publish.

## Then the rollout continues where it was

Step 1 of batch 39 is done. Still yours:

**2.** Publish — schema and code only, **do not copy dev data to production**.

**3.** Then set `AM_FORECAST_AUTO_MIGRATE=1` on production and restart, so it
applies 0020 to 0024 and records them.

**4.** Confirm on production: `schema_migration` count is 24, and
`pg_get_viewdef('v_bonus_month', true) LIKE '%cut_off_date%'` is false.

**5.** Remove `AM_FORECAST_AUTO_MIGRATE` and restart again.
