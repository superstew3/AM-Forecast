# Changes

Rebuilt from an empty database on PostgreSQL 16 following the documented
sequence, on the three supplied CSVs.

**Before:** 223 passed, 10 failed, 8 skips claimed.
**After:** 237 passed, 7 skipped, 0 failed. Six consecutive runs stay green and
leave the data unchanged.

Replace these nine files in place. No migration is required — the two production
fixes are in the import and matching code, not the schema.

---

## 1. The reported reconciliation defect does not exist in the data

On a clean rebuild AnneM Goodchild has an ordinary budget row of $2,328.25
(her August original forecast of $2,165.81 at 7.5%), nothing is orphaned, and
`gap_reconciles_to_budget_less_outlook` is true.

Running `pytest tests/` deleted all 256 August original forecast rows. The
budget then collapsed to July alone:

| | after rebuild | after the old test suite |
|---|---|---|
| original forecast rows | 27 (Jul + Aug) | 13 (Jul only) |
| original forecast total | $460,528.18 | $261,481.51 |
| total budget | **$495,067.79** | $281,092.62 |
| managers in budget | 14 | 13 |
| outlook rows with no budget | 0 | 1 |

The `$281,092.62` in the handover's operating-state table is $261,481.51 × 1.075,
which is July on its own. It was recorded from a database that had been through
a test run.

The stated cause did not hold either. There are no July actuals: all 299 sales
rows carry period month August 2026. AnneM's $2,165.81 reaches the outlook
through the forecast branch of `v_outlook_month`, not the actual branch.

**Neither remedy in the brief was right.** A zero budget row encodes a fiction;
excluding her from the outlook hides real forecast income. Both fix a symptom on
a corrupted database.

---

## 2. Production fix: rollback destroyed the Original Forecast baseline

`app/importers/commit.py`

Accepting a snapshot over an open month is delete-then-insert, so the month's
Original Forecast rows are re-stamped with the new batch. `_rollback_renewals`
then deleted by `established_batch_id` — removing a baseline the earlier,
surviving snapshot owned — and repointed `latest_snapshot_id` to the newest
surviving snapshot while doing nothing equivalent for Original.

The month was left with a live Latest Forecast and no budget. Every manager in
it silently lost their target, and the only visible symptom was a reconciliation
gap with no traceable source.

Traced:

```
after rebuild          orig month=2026-08-01 est_snapshot=1 rows=256   cover original=1 latest=1
after second accept    orig month=2026-08-01 est_snapshot=2 rows=256   cover original=1 latest=2   <- rows and coverage disagree
after rollback         (August gone)                                    cover original=1 latest=1   <- coverage points at nothing
```

Two changes:

- **Accept** now moves `forecast_month_coverage.original_snapshot_id` to the
  snapshot the rows actually carry, for the months it wrote. Closed, pinned and
  already-established months are untouched.
- **Rollback** re-establishes the Original Forecast from the newest surviving
  snapshot that covers each open, unpinned month, mirroring what it already did
  for Latest. The result now reports `original_forecast_rows_restored`.

Accept-then-rollback is now an exact round trip in rows, totals and coverage.

---

## 3. Production fix: the matcher duplicated decided candidates every run

`app/matching/engine.py`

`match_candidate` is cleared only for `status IN ('pending','superseded')` —
correct, since accepted and rejected rows are a reviewer's work. But candidate
generation had no guard against regenerating a pair that already carried a
decision, so every run added another identical accepted/rejected row.

Nine runs left nine accepted and nine rejected rows for the same policy pair on
transaction 74. Anything counting the review queue inflates, and a transaction
appears to have more competing policies than it has.

A `NOT EXISTS` guard against decided candidates added to all three inserts.
Repeated matcher runs now hold the candidate table steady instead of adding
~538 rows each time.

---

## 4. Test helper paired managers with months they had no budget in

`tests/conftest.py`

`budgeted_manager` returned the alphabetically first manager with *any* budget;
callers then asserted across every month from `budget_months`. The two lists do
not form a grid — a manager can hold business in one month and none in another.
Once AnneM had her budget back she sorted first, had no July row, and five
stage 7 tests failed on `StopIteration` or on `0.00 > 0.00`.

Now restricted to managers carrying a non-zero budget in every month that has
one.

---

## 5. Four tests encoded the pre-0017 rule or a dataset that no longer exists

Rewritten to **closed and pinned frozen, open updated**, and renamed, since the
old names described the wrong rule:

| was | now |
|---|---|
| `test_original_forecast_frozen_after_second_snapshot` | `test_second_snapshot_holds_closed_months_and_updates_open_ones` |
| `test_added_policy_has_zero_original_and_positive_latest` | `test_added_policy_original_follows_the_state_of_its_month` |
| `test_budget_does_not_move_when_latest_forecast_moves` | `test_budget_of_a_held_month_does_not_move_when_the_forecast_does` |
| `test_july_residual_pending_policies_not_in_original` | `test_residual_pending_policies_did_not_establish_a_baseline` |

The month split is derived from the cut-off and the active locks
(`held_and_open_months` in `tests/test_stage3_forecast.py`), not from a named
calendar, so it follows the data.

The residual-pending test previously asserted July had no Original Forecast at
all, true only while the month had no baseline. July is now pinned from the
April extract, so what survives is the provenance rule: the baseline came from a
deliberate pin, not from the two leftover rows. Derived from the
`residual_pending` flag rather than naming July.

`test_19_accept_uses_the_exact_previewed_figures` pointed at
`Sales_Transaction_List_25-26.csv`, which is not in the bundle. It now uses the
configured fixture, with the invoice offset raised to 90,000,000 so a larger
export cannot grow into the fixture range.

The two stage 4 apportionment tests took an unordered `array_agg(policy_id)` and
assumed the first two entries were different policies. Replaced with a shared
`contended_transaction` helper: `array_agg(DISTINCT ...)`,
`HAVING count(DISTINCT policy_id) >= 2`, ordered by transaction id, skipping
honestly when no transaction is contended. These only failed from the third
consecutive suite run, which read as flakiness.

---

## 6. New tests

- `tests/test_stage2_import.py::test_rollback_of_a_replacing_snapshot_restores_the_previous_baseline`
  — the accept/rollback round trip, asserting rows, totals and coverage all
  return, and that restored equals deleted.
- `tests/test_stage9_base_state.py::test_coverage_names_a_snapshot_that_still_holds_the_forecast`
  — no covered month may point at a snapshot with no surviving Original rows.
  This is the invariant that would have caught the defect immediately.
- `tests/test_stage9_base_state.py::test_every_manager_in_the_outlook_has_a_budget`
  — Budget and Outlook must cover the same managers, so the totals keep
  reconciling to the per-manager rows.

---

## Skips: 7, not 8

All state a reason and all are honest — the sample has no completed month
holding actuals, no unusable baseline, and one month dominating it.

```
test_stage1.py:292      no unusable baselines in this dataset
test_stage3_forecast.py:61   no completed month holding actuals  (x2)
test_stage4_matching.py:415  one month dominates this dataset
test_stage4_matching.py:464  one month dominates this dataset
test_stage4_matching.py:517  no month open for revision after the cut-off
test_stage6_longevity.py:299 no completed month with both budget and actuals
```

---

## Two calls left to you

**`added_after_original` is a misnomer for an open month.** The addition is
against the previous snapshot, not against the baseline — under 0017 an open
month's baseline includes the added policy. The classification is accurate; only
the name reads oddly. Documented in the rewritten test rather than renamed on my
own initiative, since it is a stored `movement_type` value.

**`compute_movement` runs after the Original has been replaced.** It therefore
compares against a baseline the same accept just rewrote. Defensible under the
new rule, but worth confirming it is intended rather than incidental.

---

## Verified figures on a clean rebuild

| Measure | Amount |
|---|---|
| Sales, net (SIG income) | $80,440.80 |
| Sales, gross (audit only) | $85,593.84 |
| Forecast, July 2026 (pinned) | $261,481.51 (388 policies) |
| Forecast, August 2026 | $199,046.67 (256 policies) |
| Total budget FY2026-27 | **$495,067.79** |
| Latest outlook | $199,046.67 |
| Remaining gap | $296,021.12 |

`GET /api/base-position` returns `is_base_state: true` with all six checks
passing.
