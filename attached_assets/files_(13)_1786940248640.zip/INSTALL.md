# Install: replace the whole tree, not selected files

## Why this changed

Four attempts at shipping selected files have each failed on a different missing
symbol: `forecast_month_lock`, `primary_assoc_comm_sum`, `BASE_POSITION`,
`RENEWALS`. Every one was the same root cause and my checks kept missing it.

This repl's `app/` tree is from an older lineage than the codebase these fixes
come from. Individual files cannot be made consistent with it one at a time —
each fix exposes the next mismatch, and there is no reason to think the fourth
was the last.

`am_forecast_app.tar.gz` is the complete tested tree: `app/`, `scripts/`,
`migrations/`, `tests/`. 96 files. Verified before packaging — every API module
imports cleanly and the suite runs 237 passed, 7 skipped against it.

Your `operations.py` imports `RENEWALS` from validation. The supplied
`operations.py` does not import it at all. That is the shape of the problem:
not a missing constant, a different generation of the same file.

## Install

**1. Preserve your auth work first.**

```bash
mkdir -p ../am_forecast_prev
cp -r app scripts migrations tests ../am_forecast_prev/
```

**2. Extract over the top.**

```bash
tar xzf am_forecast_app.tar.gz
```

This replaces `app/`, `scripts/`, `migrations/` and `tests/` wholesale.

**3. Decide on `bootstrap.py`.**

The archive contains `bootstrap.py.SUPPLIED` at the top level rather than at
`app/bootstrap.py`, deliberately — extracting does **not** overwrite yours.

Your `app/bootstrap.py` is left exactly as it was. The supplied `main.py` calls
it as `from ..bootstrap import run` then `run(DSN)`, behind
`AM_FORECAST_AUTO_MIGRATE`. If yours exposes `run(dsn)`, it will work unchanged.

```bash
diff app/bootstrap.py bootstrap.py.SUPPLIED
```

**Report the diff.** Do not merge it. If yours has the auth-seeding fix and the
supplied one has later changes, that is a decision, not a merge.

**4. Confirm the application imports before touching the database.**

```bash
python3 -c "import sys; sys.path.insert(0,'.'); import app.api.main; print('ok')"
```

This must print `ok`. If it raises another ImportError, stop and report it —
that would mean the archive did not fully replace something.

**5. Then RUNBOOK.md, from step 2.**

`scripts/set_month_forecast_from_file.py` is in the archive. Step 4 will work.

## What is not in the archive

- `app/bootstrap.py` — yours is kept
- `fixtures/` — your data files are untouched
- `web/` — the frontend is not part of this
