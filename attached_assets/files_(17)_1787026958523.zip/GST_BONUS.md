# Bonus is now paid GST exclusive

## What changed

`migrations/versions/0019_bonus_gst.sql` adds `bonus_gst_divisor` to
`reporting_settings`, defaulting to 1.1, and divides the **six payment figures**
by it:

| View | Figures divided |
|---|---|
| `v_bonus_quarter` | base_bonus, above_target_bonus, total_bonus, bonus_at_target, projected_bonus |
| `v_bonus_month` | indicative_bonus |

Nothing else moves. Income, targets, variance, achievement, projected income and
income_still_required stay GST inclusive, because they measure performance rather
than payment and are compared against the rest of the application.

`indicative_bonus` is divided too. A monthly figure on a different basis from the
quarterly payment it anticipates would be read as an error in one or the other.

## Verified

A manager pushed above target, the same quarter read twice with the divisor at
1.0 and then 1.1:

```
figure                     GST incl     GST excl    ratio
base_bonus                    54.15        49.22  0.90896
above_target_bonus         80342.76     73038.87  0.90909
total_bonus                80396.91     73088.10  0.90909
bonus_at_target               54.15        49.22  0.90896

PERFORMANCE FIGURES - must be identical:
  actual_income               404042.05 vs      404042.05  OK
  budget_target             2328.245750 vs    2328.245750  OK
  target_achievement     173.53926233 vs    173.53926233  OK
  income_still_required            0.00 vs           0.00  OK
  projected_income                 None vs           None  OK
```

0.90909 is 1/1.1 exactly. The two figures at 0.90896 are rounding on amounts
under $60, correct to the cent.

Suite: 232 passed, 12 skipped, 0 failed on a clean rebuild.

## The rate is a setting, not a literal

`bonus_gst_divisor` is read from `reporting_settings`, with a positive-value
constraint. A hard-coded 1.1 buried in a view is the same shape as the exclusion
rules that turned up hand-copied into four separate files this session, each
wrong differently and none of them visible.

The tests were changed the same way. `test_stage8_bonus.py` asserted
`(target - expected) / 3` with the divisor written into the assertion, so it
broke the moment the scheme changed. It now reads the scheme from the database
through one `base_bonus()` helper.

## Required before this goes in front of anyone

**Every place a bonus figure is displayed must say "GST exclusive."**

This is the only GST-exclusive figure in the system, and your standing convention
is that everything is GST inclusive and says so. A bonus compared against a GST
inclusive target by somebody who was not told will look about 9% wrong with no
explanation, and it is a payment figure, so the complaint will be about money.

Both views carry `bonus_is_gst_exclusive` for the interface to read, so the label
does not have to be hard-coded in the frontend.

## Effect on payments

A bonus that previously calculated at $10,000 now pays **$9,090.91** — 9.1%
lower. Worth confirming that is the intended commercial effect before anyone is
paid on it.

## Install

```bash
tar xzf am_forecast_app.tar.gz
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/versions/0019_bonus_gst.sql
AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Then report, before and after, for a manager who has exceeded target:

```sql
SELECT canonical_manager, base_bonus, above_target_bonus, total_bonus,
       bonus_at_target, actual_income, budget_target, target_achievement
FROM v_bonus_quarter WHERE total_bonus > 0 ORDER BY total_bonus DESC LIMIT 5;
```

Every bonus figure should be 1/1.1 of what it was. Any performance figure that
moves means something was divided that should not have been.
