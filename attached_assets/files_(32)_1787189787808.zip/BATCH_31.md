# Batch 31 — the bonus tracker was wrong about everybody

Seven files: one migration, three Python, three frontend.

## 1. Everyone read as "well behind" and almost nobody was

`v_bonus_quarter` counted months elapsed as every month up to **and including**
the current one. So on 19 August, with July closed and August three weeks in, it
compared **July's income against July plus August's target**.

```
AnneM Goodchild   income to date  $20,855.09
                  target to date  $36,724.15   (July 18,012.72 + August 18,711.43)
                  pace                  56.8%  "well behind"
```

Against July alone -- the only month that has finished -- she is on $20,855.09
against $18,012.72. That is **115.8% and ahead**. The page said the opposite about
almost everyone, and reported the projected bonus for the whole business as zero.

Same fault the reporting rules warn about, in a new place: a whole period's target
against a part period's income. It would have been wrong every month of the year,
not only this one.

**Migration 0022.** Elapsed now means strictly before the current month.
`actual_income_completed` is added beside the running total, so what has been
earned and what can be judged are two named columns rather than one doing both
jobs.

## 2. And a second trap behind it

With that fixed, a completed month whose sales are not yet imported still gave
0% and "well behind" -- because `SUM` over no rows is `NULL`, and null was being
read as zero. Those mean opposite things: one is a real result, the other is a
month nobody has uploaded.

Pace is now **withheld** rather than reported as nought. Verified: with no
completed-month actuals loaded, every manager reads **"in progress"** instead of
"well behind".

That is the part that makes it error-proof going forward. Whether the sales file
arrives on the 1st or the 20th, the tracker never invents a verdict it cannot
support.

## 3. The banner said the wrong date, in the wrong format

Every page read `Reporting cut-off 2026-07-31`. Two wrong things at once: that a
setting somebody maintains still governs the figures -- it has not since
migration 0020 -- and, throughout August, that the system thought it was July.

Now `Reporting Aug 2026 · Australia/Melbourne`, from the calendar, needing nobody
to advance it.

On dates generally: `dateAU` and `monthAU` already existed and already render
Australian (`19 Aug 2026`, `Aug 2026`). The banner was printing the raw ISO string
from the payload instead of using them. Everything else on the site already uses
these helpers, so the site is consistent once this one is fixed.

## Install

```
0022_elapsed_excludes_current_month.sql -> migrations/versions/
bonus.py        -> app/api/bonus.py
core.py         -> app/api/core.py
performance.py  -> app/api/performance.py
ui.tsx          -> web/src/components/ui.tsx
api.ts          -> web/src/lib/api.ts
Performance.tsx -> web/src/pages/Performance.tsx
```

Apply the migration, build, run the suite, restart the workflows, publish.

**Check afterwards on the bonus tracker:** managers who beat their July target
should read *ahead* or *on pace*, not *well behind*, and "months elapsed" should
be 1 of 3 rather than 2.

## Still open

**Period controls on five pages** -- Business, AllManagers, ManagerDetail,
ForecastHistory, ManagerIndex. Consistency, not correctness.

**August actuals.** WinBEAT is giving you closed periods only, so August is not
exportable until period 136 closes. Worth checking whether that report can be run
by date range instead -- the original bundle contained a file covering 1 to 11
August, so it can be done. If it cannot, the month under way will always show no
actuals until the period closes, and that is worth knowing rather than reading as
a fault.
