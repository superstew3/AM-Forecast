# Batch 33 — the test that asserted the bug

One file: `tests/test_stage8_bonus.py`.

## What happened

`test_projection_scales_the_elapsed_pace` asserted the old flat formula --
`actual * months_in_quarter / months_elapsed` -- which is precisely what batch 32
replaced. My omission: I changed the calculation and left the test asserting the
thing I had just removed.

Your agent was right to report it rather than adjust it. A test failing after a
deliberate change is either a stale expectation or a real regression, and the two
look identical until somebody reads them.

## The test now asserts the rule

A manager running at X% of pace is projected to finish at X% of target. Written
against `actual_income_completed` and `budget_target`, so it follows the
calculation rather than restating it.

## Two guards added, because one test was not enough

**`test_a_projection_needs_a_completed_month_behind_it`** -- null, not nought,
when there is nothing to project from. Reporting zero reads as "on course to earn
nothing", which is a verdict rather than an absence. Same conflation of null with
zero that made every manager read as well behind while the sales file had simply
not arrived.

**`test_a_projected_bonus_needs_a_projection_above_target`** -- never a bonus for
a manager the same view reports as behind. This is the pairing that made the
original bug visible:

```
Michael Stewart   flat x3 projects 207,150 vs target 193,011 | pace <100%  -> guard FIRES
AnneM Goodchild   flat x3 projects  62,565 vs target  64,672 | pace >=100% -> guard FIRES
```

Verified against the old formula: it fires on **both**. Whatever the arithmetic,
a bonus projected for somebody behind the pace and none for somebody ahead cannot
both be right, and the suite now says so.

That is the part worth having. The corrected assertion checks today's formula;
this one checks the property that has to hold whatever formula anyone writes next.

## Install

Replace `tests/test_stage8_bonus.py`. Run the suite -- expect the failure to clear
and two extra tests to pass. Commit and push. No migration, no restart needed.
