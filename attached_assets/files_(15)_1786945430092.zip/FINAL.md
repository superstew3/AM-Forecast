# Upload enforcement is in. What that means, and what it does not.

## The last real gap is closed

The accept path now refuses to write a locked month. Proven:

```
August before upload: $291,970.36
August after  upload: $291,970.36
PROTECTED
```

That is a full renewals file being accepted, containing August rows, leaving the
locked August baseline untouched. Before this change it would have overwritten
it.

It tests `forecast_month_writable()` — after the current calendar month in
Melbourne, not pinned, or covered by an unconsumed admin override. It no longer
consults the reporting cut-off. That matters: the cut-off is a setting somebody
maintains, and while it sat wrong for a week at 2025-12-31, every upload wrote
months it had no business touching. A calendar cannot be left stale by accident.

## Install and confirm

```bash
tar xzf am_forecast_app.tar.gz
AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Nothing to re-run against the database. July and August stay as they are.

## Monthly routine, from here

1. **Last few days of the month**, pull the renewals export and upload it. It
   updates every month after the current one and cannot touch anything earlier.
2. **Any time**, upload transaction files. They only ever add actuals and cannot
   affect a target.
3. Nothing else. The lock boundary moves itself at midnight on the 1st, in
   Melbourne time.

Miss the window in step 1 and the next month keeps whatever the last pre-month
file said, permanently, unless an override is granted. That is the design, and
it is why the timing matters.

## What is still not built

- **Admin override endpoint.** The table and functions exist; the API does not.
  A locked month can only be changed by running a script directly.
- **API and view cut-over.** The dashboard still reads the old cut-off views.
  0018's views run alongside them and are not yet what the screens show.

## Four findings still open on your data

Unchanged, and none reproducible from the sample:

- manager matrix $340,341.83 against v_actual_month $756,700.56
- Anastasia K missing from non-ranked totals
- preview reconcile off by $52,276.36
- excluded-row count off by one, 975 against 974

The first two are probably one manager-mapping bug. Start there.

## On "no future errors"

I cannot promise that and you should not accept it from me. This session found
defects that had been sitting in the code for months, and produced several of its
own — a check that failed on a correct cut-off, a rebuild that wiped July, a
duplicated exclusion rule copied wrong.

What has changed is narrower and real: the rules that matter now live in one
place each and are asked rather than restated. The month boundary is
`forecast_month_is_open()`. Exclusions are `ExclusionEngine`. Coverage is
`actual_load_state()`. Tests call those functions instead of reimplementing them,
which is how three of them ended up disagreeing with the importer today.

Duplicated rules were the single largest source of silent wrong numbers here.
There are none left that I know of. That is a much smaller claim than "no future
errors", and it is the one I can support.
