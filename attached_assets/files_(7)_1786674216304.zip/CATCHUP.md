# Catch-up: bringing this deployment from 0015 to 0017

**Read all of this before running anything. Step 3 will destroy the entire
renewal forecast if step 4 is skipped.**

## What the diagnostic established

This repl has never had migrations 0016 or 0017. Both the files and the database
are consistently at 0015.

One correction to the earlier report: `forecast_month_coverage` is created in
migration **0001**, not 0016. The database is not ahead of the migration files
in any respect. It is cleanly at 0015, which is simpler than it first appeared.

## I broke something. Fix this first.

The nine files uploaded earlier came from a codebase at 0017. Three of them
reference `forecast_month_lock`, a table that migration 0017 creates and this
database does not have:

- `app/importers/commit.py` (3 references — 2 predate my changes, in the accept
  path)
- `tests/test_stage3_forecast.py`
- `tests/test_stage9_base_state.py`

**Renewals upload and rollback are broken on this deployment right now.** They
will raise `UndefinedTable: relation "forecast_month_lock" does not exist`.

This resolves itself once 0017 is applied below. If the catch-up is not going
ahead today, restore the previous `app/importers/commit.py` from Replit's file
history in the meantime.

---

## Step 1 — pre-flight

```bash
bash scripts/preflight_0016.sh
```

Reports whether the associate columns hold data, and what the income change will
be. **Stop and report if it says STOP.** Expect roughly minus 6 to 7 per cent on
sales.

## Step 2 — back up

Replit's Postgres supports point-in-time restore, but take an explicit dump too:

```bash
pg_dump "$DATABASE_URL" > backup_pre_0016_$(date +%Y%m%d_%H%M).sql
```

Confirm the file exists and is non-trivial in size before continuing.

## Step 3 — apply the migrations

Put `0016_primary_associate_income.sql` and `0017_forecast_month_locks.sql` in
`migrations/versions/`, then:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/versions/0016_primary_associate_income.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/versions/0017_forecast_month_locks.sql
```

Both are verified to apply cleanly in place on a populated 0015 database.

## Step 4 — DO NOT SKIP: backfill the renewals

**At this point the entire renewal forecast reads $0.00.** The migration
succeeded. Nothing errored. The figure is zero anyway.

0016 treats the two sides differently:

| | Before 0016 | Effect of migrating in place |
|---|---|---|
| Sales `primary_assoc_amount` | **exists**, importer writes it | migrates correctly |
| Renewals `primary_assoc_comm_sum` / `_tax_sum` | **do not exist** | added as `NOT NULL DEFAULT 0` |

`forecast_contribution` then becomes a generated column reading those zeros. The
renewal forecast, the budget derived from it, and every achievement and bonus
figure beneath it all go to zero together.

Verified: a book of $200,188.42 became $0.00 on a clean migration run.

It is recoverable because `forecast_policy.source_row` retains the full original
CSV row — the "nothing is silently dropped at import" rule paying for itself.

```bash
psql "$DATABASE_URL" -f scripts/backfill_0016_renewals.sql
```

The script prints, before committing:

- `policies_without_source_associate_data` — **must be 0**. Anything else means
  those policies need re-importing.
- the recovered `forecast_contribution` and `gross_for_audit`.

The gross should still reconcile to the source report exactly as it did before
the migration. The contribution should sit a few per cent below it. If either
looks wrong, `ROLLBACK` rather than commit, and report.

Verified end to end: $200,188.42 → $0.00 → $200,188.42.

## Step 5 — the remaining application files

Replace with the versions supplied:

| File | Destination |
|---|---|
| `validation.py` | `app/validation.py` |
| `test_stage6_longevity.py` | `tests/test_stage6_longevity.py` |
| `test_stage8_bonus.py` | `tests/test_stage8_bonus.py` |

These are the three the diagnostic identified as behind. `validation.py` adds
`sales_expected`; the two tests drop assertions pinned to one export.

## Step 6 — verify

```bash
bash scripts/check_state.sh
bash scripts/preflight_0016.sh          # income should now match the "after" column
AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Expect zero failures. Do not expect a particular pass count — this book is
larger than the reference sample.

---

## Files deliberately NOT included

`app/bootstrap.py`, `app/api/main.py` and `tests/test_stage10_auth.py` carry an
auth-seeding fix made in this repl. **I did not send those and I am not
replacing them.** They may well be newer here than anywhere else.

After step 6, if any auth test fails, report it rather than resolving it — that
would mean the auth fix and the 0016/0017 work need reconciling by hand, and
that is a decision, not a merge.
