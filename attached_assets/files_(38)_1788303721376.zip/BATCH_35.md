# Batch 35 — why the August upload vanished

**Ten files. Supersedes both earlier batch 35 drops — take all ten.**

Six API modules, three test files, no migration.

## What happened

The upload worked. The rows went into `sales_transaction`. Then every reporting
surface threw them away.

Migration 0020 moved every **view** onto the calendar. **Eight places in the API
were missed** and kept deriving their month boundary from `cut_off_date`, still
reading 2026-07-31. So the views knew August had started and the endpoints did
not — and the endpoints are what the pages call.

The worst, in `reporting.py`:

```python
if period == "ytd":
    rows = [r for r in rows if r["period_month"] and r["period_month"] <= cut]
```

A Python filter discarding every row after the boundary before aggregating. An
accepted import silently removed, with a reporting setting deciding whether an
upload was visible. Nothing errored; the numbers just did not move.

## And then I got the fix wrong

The first attempt pointed everything at `reporting_current_month()`. Your agent
caught that this counts the month under way as finished, and produced a real
off-by-one: year-over-year returned a full-year total where the last completed
month was May.

**There are two boundaries, and collapsing them is what caused both faults.**

| Question | Governs | Includes the month under way |
|---|---|---|
| Has this month **started**? | whether income is **shown** | yes |
| Has this month **finished**? | whether anything is **judged** | no |

August income belongs on the page the day it is imported — it has been earned.
But nothing about August should be measured against a whole month's target,
which is the fault fixed on the bonus tracker in migration 0022 and the one that
has recurred through this system more than any other.

`core.py` now exposes `current_month()` and `last_completed_month()`, named for
the question each answers. Year-over-year and budget-to-date take the completed
one; income to date takes the current one.

## The eight sites

`reporting.py` `_MANAGER_SQL` · **`reporting.py` the YTD row filter** ·
`analytics.py` `_cut_month()` · `manager_detail.py` · `operations.py` ·
`settings.py` `/api/periods` · `main.py` health check ·
**`main.py` `/api/base-position`** — the one my own sweep missed and the guard
test caught.

## Two stale tests, both genuinely stale

**`closed_month` in `conftest.py`** simulated a completed month by rolling
`cut_off_date` back. Once the endpoints stopped reading it, that did nothing. It
now overrides `reporting_current_month()`, captured with `pg_get_functiondef` and
restored afterwards. The function is `STABLE`, so the override applies per
statement with nothing cached.

**`test_future_months_are_not_reported_as_unavailable`** asserted every month
after the closed one was `future` — true while one stored cut-off drew a single
line between past and future. The calendar draws two lines: before, under way,
and after. The month under way is exactly where income must still be shown, so
calling it future would blank the figures somebody uploaded this morning.

**`test_01_base_operating_position_reconciles`** read `cut_off_month_is_complete`,
which this batch renamed. `.get(key, True)` meant the guard silently stopped
firing — a default that hides a rename is worse than a `KeyError`, which would at
least have said so.

## Traced by hand

I could not run the suite: my environment lost its database partway through. The
boundary logic is traced against the fixture's own dates instead:

```
month       month_status   in YTD income   in budget_to_date
2025-05-01  completed              True                True
2025-06-01  in_progress            True               False
2025-07-01  future                False               False

year-over-year cut = 2025-05-01  -> YTD through May   [test expects May]
future months = Jul, Aug          [June excluded, correct]
```

Every changed file parses, and the boundary guard reports clean across `app/api`.

## Install

Replace all ten, build, run the suite, restart the workflows, publish.

If anything still fails, send the traceback. Your agent has been right on every
one of these so far and I would rather read it than guess again.

## Then check

August income should appear on the business page, in the account-manager figures
and in the month-by-month grids, **without re-uploading anything**.
