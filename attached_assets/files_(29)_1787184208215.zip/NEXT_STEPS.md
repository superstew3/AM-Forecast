# Where the system stands, and what is worth doing next

## Batch 29 — attached, three files

`core.py`, `reporting.py`, `manager_detail.py`.

Removes the last hard-coded year. Two endpoints carried
`if financial_year == 2026:` with July named in the text -- true today, silently
wrong from 1 July 2027, when the note would keep appearing on a year it does not
describe.

The distinction is already in the data: a month established from supplied figures
carries `grain = 'manager_month'`, one built from an extract carries `'policy'`.
So `supplied_month_note()` reads it rather than remembering it. Verified -- it
still names July 2026 today, and will name whatever applies in FY2027, or nothing.

That is Replit's suggested task 1, done.

## On Replit's other two suggestions

**"Show the new month-by-month performance view on screen"** -- yes, and it is the
highest-value work left. `/api/performance` exists and returns everything; no page
calls it. Until then the rules agreed for the two-ledger model stay invisible: a
month still running can be read as a result, a month with no target says nothing,
and an unimported month looks like a month where nobody earned anything.

**"Add tests for the manager detail page and other untested endpoints"** -- worth
doing, lower urgency. Ten endpoints have none, including `/managers/{manager}/detail`,
which is the most-used page, and every override route. These will not produce a
wrong number tomorrow; they mean a future change can break something quietly.

## The full list, in the order I would take it

1. **Consume `/api/performance` in the UI.** Biggest gap between what is built and
   what can be seen.
2. **Business page.** Still twelve figures across two rows with three repeats, and
   the only page from the original brief not rebuilt.
3. **Override UI.** `/api/forecast-months/override` works and is reachable only by
   running SQL. It was asked for as "a smart and easy override for an
   administrator".
4. **Tests for the ten untested endpoints.**
5. **Period controls on the five remaining pages** -- Business, AllManagers,
   ManagerDetail, ForecastHistory, ManagerIndex. Bonus, Budget, New Business and
   Returns have them; the rest do not, which is inconsistent to use.

## Two things that are not code

**A current sales export.** Actuals stop at 31 July. Every "to date" figure is
missing three weeks, and the bonus pace has no current income behind it. Nothing
in the software fixes this.

**Pull the renewals export in the last days of the month.** A file pulled on the
14th loses whatever renewed in the first fortnight, and once a month begins that
is locked. July is the evidence: the mid-month extract held 211 policies at
$182,416.57 against a real $331,676.03.

## What is genuinely finished

Migrations through 0021. The calendar cut-over, so no monthly setting to maintain.
GST-exclusive bonus, labelled on screen. Upload enforcement, verified against a
real attempt to overwrite. Exclusion rules in one implementation after four
hand-written copies were found and removed. A rebuild that restores July, August
and the ranking flags. Bonus, Budget, New Business and Return Income rebuilt.
242 tests passing.
