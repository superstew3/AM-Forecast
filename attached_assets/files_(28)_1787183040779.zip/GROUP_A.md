# Group A — backend

Three things, all verified against a live database. No frontend changes yet.

## 1. The two-ledger model is reachable

`app/api/performance.py` — new. Migration 0018 built seven views and **nothing
read them**. Every rule agreed for that model was invisible on screen:

- a month still running was scored as though finished
- a month that began without a target said nothing
- a month whose transactions were never imported showed $0.00 and 0%, which
  reads identically to a month where nobody earned anything
- bonus figures carried no GST label

`GET /api/performance` now returns it, with the wording taken from the views
rather than reinvented in the interface:

```
AnneM Goodchild  2026-07-01  completed    actuals_not_loaded
                 "Actuals not loaded - outlook using expected income"
AnneM Goodchild  2026-08-01  in_progress  in_progress
                 "Month in progress - actual income to 11 Aug"

coverage: July  load_state=none
          Aug   load_state=partial, loaded_to=2026-08-11
```

Also `GET /api/performance/months` for a headline strip, and the payload carries
missing forecasts, coverage and any baseline still on the pre-associate basis.

**The frontend still has to consume this.** That is Group B.

## 2. The cut-off no longer blocks an upload

`app/forecast/coverage.py`. A renewals file was refused whenever transactions ran
past the stored cut-off:

> *Reporting Cut-Off Date is 2026-07-31 but actual transactions run to
> 2026-08-11. Update the cut-off before accepting...*

That guarded a real hazard while the cut-off decided which months were finished.
Migration 0020 moved that to the calendar, and the importer already refuses to
write any month at or before the current one. So it blocked a legitimate upload
until somebody changed a setting that no longer affects the outcome.

Now reported, not enforced. The two genuine blocks — mass removal, absent month —
are untouched.

## 3. Every endpoint resolves its own financial year

Ten endpoints defaulted to `Query(2026)`. A literal that would have gone quietly
wrong on 1 July 2027: last year's figures to anyone who did not pick a year, with
nothing on screen to say so.

`current_financial_year()` in `core.py` derives it in Australia/Melbourne through
the same function everything else uses. Verified — all ten return 2026 with no
year supplied.

### One regression I caused and caught

I first defaulted the year inside the shared `Filters` dependency. Tidier, and it
broke the export: it aliases only the FIRST condition of the WHERE clause, so
adding a year condition ahead of the others left the next column unqualified and
ambiguous across a join.

Narrowed to the one endpoint that reads its year only through `Filters`, with a
comment explaining why the shared version is wrong. A default that changes the
SHAPE of a query does not belong somewhere that widely used.

## Install

Replace, all under `am_forecast/`:

```
app/api/performance.py      (new)
app/api/main.py             (registers it)
app/api/core.py             (current_financial_year)
app/forecast/coverage.py    (upload no longer blocked)
app/api/reporting.py  analytics.py  bonus.py
app/api/forecast_history.py  manager_detail.py  operations.py
```

Then run the suite and report. My local suite shows failures that are my own
harness — I loaded data outside the documented sequence and `forecast_policy` is
empty here, which fails tests that have nothing to do with these changes. Your
environment was at 242 passing; that is the number to compare against.

**If anything fails, send the traceback rather than adjusting it.** Three of these
files are touched by almost every request.

## Still to do

- **Group B** — consume `/api/performance` in the UI, GST label on bonus figures,
  the Business page, the override UI
- Ten endpoints still have no test, including `/managers/{manager}/detail`
- `if financial_year == 2026` branches in `reporting.py` and `manager_detail.py`
  carry July-specific notes that silently stop applying next year
