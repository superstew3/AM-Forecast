# Group B — everything remaining

Seven files. Frontend plus one test module. No migration, no schema change.

| File | Destination | |
|---|---|---|
| `Performance.tsx` | `web/src/pages/Performance.tsx` | new |
| `Business.tsx` | `web/src/pages/Business.tsx` | replace |
| `Settings.tsx` | `web/src/pages/Settings.tsx` | replace |
| `App.tsx` | `web/src/App.tsx` | replace |
| `api.ts` | `web/src/lib/api.ts` | replace |
| `styles.css` | `web/src/styles.css` | replace |
| `test_stage11_performance.py` | `tests/test_stage11_performance.py` | new |

## 1. The two-ledger model is on a screen

New page, **Performance by month**, second in the nav. `/api/performance` had
existed since batch 28 and nothing called it, so every rule agreed for that model
was invisible. Each is now visible, and the wording comes from the database
rather than this page, so what the reader sees and what the figures mean cannot
drift apart:

```
July 2026    completed    Actuals not loaded — outlook using expected income
August 2026  in_progress  Month in progress — actual income to 11 Aug
```

The month under way sits at the top with its month-to-date figure and the note
explaining how far the actuals run. Below it, an advisories block gathers
anything a reader needs before trusting a figure: months that began with no
target, months with no transactions imported, baselines still on the old gross
basis. Those were previously discoverable one row at a time, or not at all.

Then every month for the business or for one manager, with achievement withheld
where it should be: a month not started, a month still running, a month whose
transactions are not in.

## 2. Business page — twelve figures to six

Two were repeats. **Year-to-date Budget appeared in both rows**, and Variance to
Budget restated what the gauge above already shows as a bar and a percentage.
Twelve at one size meant nothing said which was the answer.

Now three for the period selected, a rule, then three for where the full year is
heading. The two removed figures move into a sentence beneath, where they read as
context rather than competing as results.

## 3. The override is reachable

`/api/forecast-months/override` worked and could only be used by running SQL,
which is not an override anybody would use. A locked month is the right default;
a default nobody can lift is an obstruction, and obstructions get worked around in
spreadsheets where nothing is audited.

Settings now lists every forecast month with its state and whether uploads are
open, a Reopen action on the closed ones, an eight-character minimum on the
reason, and the full grant history including which upload consumed each one.

Also corrected there: the cut-off panel still described itself as governing what
counts as an actual. It has not since migration 0020. It now says what it is — a
record of what the last complete month was taken to be, deciding nothing.

## 4. Tests for the endpoints that had none

`test_stage11_performance.py`, 12 tests. Ten endpoints were unexercised,
including `/managers/{manager}/detail` -- the most-used page -- and every override
route.

They assert rules, not figures: a running month is never scored, a future month
reports nothing rather than zero, an unimported month is distinguishable from an
empty one, the target is the forecast times the uplift, the summary is the detail
added up, an override opens one month once and refuses a second grant.

**One of them was too weak and I found it by breaking the code.** Sabotaging
`month_state` so nothing was ever in progress made the tests skip and pass --
correct in principle, since a rule the data cannot exercise should not be
asserted, but useless as a guard. `test_month_state_follows_the_calendar` now
checks the boundary directly. Verified: passes when correct, fails when broken.

## Install

Replace the seven files, then:

```bash
cd am_forecast/web && npm run build
cd .. && AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Expect the baseline plus 12, so around **254 passed**. Then restart the workflows
-- this batch changes the API surface and adds a route, so a restart is needed --
commit, push and publish.

**If a test fails, paste the traceback rather than adjusting it.**

## What is left after this

Period controls on five pages that still lack them: Business, AllManagers,
ManagerDetail, ForecastHistory, ManagerIndex. Bonus, Budget, New Business,
Returns and Performance have them. It is consistency rather than correctness.

And the one thing no code fixes: **a current sales export**. Actuals stop at
31 July. Every "to date" figure is three weeks short, and the new Performance
page will say so on every row until the file goes in -- which is the page working
correctly, not a fault.
