# Manager matrix: three defects, one cause each

## What the FY2024 response proved

| | |
|---|---|
| matrix grand_total | $754,812.92 |
| v_actual_month FY2024 | $756,700.56 |
| difference | **$1,887.64** |
| Anastasia K, FY2024 | **$1,887.64** |

Exact to the cent. The matrix was dropping non-ranked managers out of the rows,
the column totals and the grand total together — so the shortfall was one
person's entire year, with nothing on screen to say a name was missing.

Internally the matrix was perfectly consistent: rows summed to column totals
summed to grand total. It was consistently wrong, which is why it took a
comparison against the view to see it.

## Fixed

**1. Non-ranked managers are counted, always.** `include_non_ranked` now decides
whether a manager is *listed*, never whether their income is *counted*. Totals
are computed from every manager regardless.

Two new fields so the omission can never be silent again:

- `totals_include_non_ranked` — always true
- `non_ranked_in_totals_not_listed` — the names counted but not shown

The frontend should print that second list under the grid: *"Totals include
Anastasia K and Cameron Stewart, who are not ranked."* A total that includes
someone invisible is exactly the fault we just fixed.

**2. A started month with no figure is `unavailable`, not `actual`.** Ten empty
months came back as `"value": null, "status": "actual"` — claiming a real number
that was not there, while the column total for the same month said
`unavailable`. The grid cannot tell $0.00 from N/A when the status field lies,
and that distinction is what the whole display convention rests on.

**3. `meta.financial_year`.** A request for 2024 returned `meta.financial_year:
2026`. The supplied `analytics.py` passes the requested year through correctly —
verified. If it still shows the wrong year after installing, the deployed file
did not replace.

## Applied to the data

```sql
UPDATE reporting_manager SET include_in_rankings = false
WHERE canonical_manager IN ('Cameron Stewart', 'Anastasia K');
```

Both now appear in totals and in drill-downs, and out of rankings.

## Install

```bash
tar xzf am_forecast_app.tar.gz
psql "$DATABASE_URL" -c "UPDATE reporting_manager SET include_in_rankings = false
WHERE canonical_manager IN ('Cameron Stewart', 'Anastasia K');"
AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Then report:

```
GET /api/analytics/manager-matrix?financial_year=2024&measure=net_actual
```

`grand_total` must be **756,700.56** and `meta.financial_year` must be **2024**.

## Then the redesign

With the matrix reconciling, the Budget and Bonus Tracker pages can be rebuilt on
figures that hold. Outstanding for that work:

- GST divisor on the five bonus payment figures
- negative months shown on the budget tracker (Strata Insurance is −$3,706.14
  this quarter, so it is live, not hypothetical)
- compare-managers by quarter and YTD, or drill into one manager
- growth goal per manager — the `growth_rate` table already supports scope,
  manager, year and quarter, so this is UI exposure rather than new capability
