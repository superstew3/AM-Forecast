# Deployment instructions

**Read this whole file before changing anything. Do not improvise beyond it.**

You are applying fixes for two production defects and a set of stale tests in the
AM income forecasting app. All eleven files are drop-in replacements or new
additions. **No database migration is required.** Both production fixes are in
application code, not the schema.

---

## 1. File manifest — put each file exactly here

Paths are relative to the repository root.

### Production code — these are the actual fixes

| File | Destination | Action |
|---|---|---|
| `commit.py` | `app/importers/commit.py` | **Replace** |
| `engine.py` | `app/matching/engine.py` | **Replace** |

### Tests

| File | Destination | Action |
|---|---|---|
| `conftest.py` | `tests/conftest.py` | **Replace** |
| `test_stage1.py` | `tests/test_stage1.py` | **Replace** |
| `test_stage2_import.py` | `tests/test_stage2_import.py` | **Replace** |
| `test_stage3_forecast.py` | `tests/test_stage3_forecast.py` | **Replace** |
| `test_stage4_matching.py` | `tests/test_stage4_matching.py` | **Replace** |
| `test_stage5_dashboard.py` | `tests/test_stage5_dashboard.py` | **Replace** |
| `test_stage9_base_state.py` | `tests/test_stage9_base_state.py` | **Replace** |

### Scripts

| File | Destination | Action |
|---|---|---|
| `check_state.sh` | `scripts/check_state.sh` | **New file** |
| `rebuild.sh` | `scripts/rebuild.sh` | **New file** |

Then:

```bash
chmod +x scripts/check_state.sh scripts/rebuild.sh
```

---

## 2. DO NOT rebuild the database

`scripts/rebuild.sh` is included for a specific future situation. **Do not run
it now.**

The development database has already been checked and is not carrying either
defect. Rebuilding would discard the current data for no reason.

Only run `rebuild.sh` if `check_state.sh` later reports a non-zero value in the
first table, and only after confirming with Sam.

---

## 3. Verify

### 3a. Run the state check

```bash
bash scripts/check_state.sh
```

**Expected:** all three values in the first table are `0`.

The second table lists every financial year and quarter with a plain-English
reading in the last column. Rows saying `no forecast baseline (expected for a
prior year)` are **normal** — that is a year with actuals but no forecast loaded,
and it is not a fault.

**Report back to Sam** any row whose reading says `INVESTIGATE`, including the
financial year and quarter.

### 3b. Run the test suite

The tests need to know where the source CSVs live. Check the top of
`tests/conftest.py` — `FIXTURE_DIR` defaults to `/mnt/user-data/uploads`, which
does not exist on Replit. Either set the environment variable, or change that
default line to the directory holding the CSVs.

```bash
AM_FORECAST_FIXTURES=<directory holding the CSVs> pytest tests/ --dsn "$DATABASE_URL"
```

**Expected: zero failures.**

Do **not** expect a specific pass count. On the reference three-file sample this
is 237 passed / 7 skipped. The development database holds the full book, which
is larger and spans twelve forecast months, so the pass and skip counts will
differ. What matters is that nothing fails.

### 3c. Run the suite three times in a row

```bash
for i in 1 2 3; do AM_FORECAST_FIXTURES=<dir> pytest tests/ --dsn "$DATABASE_URL" -q | tail -1; done
```

All three must pass. This specifically checks the matcher fix: before it, the
third consecutive run failed because match candidates accumulated.

---

## 4. If a test fails

**Report the failure to Sam with the full traceback. Do not modify the test to
make it pass, and do not modify the production code.**

These tests were rewritten deliberately against the current business rules. A
failure on the full dataset most likely means the rewritten test is still pinned
to something the reference sample happened to have. That is a real finding and
Sam wants to see it, not have it papered over.

---

## 5. What changed and why

Short version, so you know what you are looking at.

**`app/importers/commit.py` — rollback destroyed the forecast baseline.**
Accepting a renewals snapshot over a month that has not happened yet replaces
that month's Original Forecast and stamps the rows with the new batch. Rolling
that upload back then deleted those rows — including the baseline the earlier,
still-present upload owned. The month kept a live forecast and lost its budget
entirely, silently. Accept now keeps coverage in step with the rows, and rollback
re-establishes the baseline from the newest surviving snapshot, mirroring what it
already did for the Latest Forecast.

**`app/matching/engine.py` — the matcher duplicated decided candidates.**
Accepted and rejected match candidates are deliberately kept across runs, but
candidate generation had no guard against regenerating them. Every run added
another identical row. A `NOT EXISTS` guard was added to all three inserts.

**Tests.** Four encoded the pre-migration-0017 rule that the Original Forecast
never moves, which was deliberately replaced by "closed and pinned months frozen,
open months updated". One pointed at a CSV that no longer exists. Two assumed an
aggregate contained distinct policies. One helper paired managers with months
they had no budget in. Three new tests were added, including two standing
invariants that would have caught the rollback defect immediately.
