# Batch 36 — a period that has not started reporting income

Two files: `app/api/reporting.py` and `tests/test_stage13_boundary.py`.

## What your agent found

`has_started` and the income sum were computed by different logic, and nothing
made them agree. So one row could say a quarter had not begun and report
$107,244.15 of income in the same breath.

The `cut` filter ran only for `period == "ytd"`. At quarter and month grain the
rows went into `_aggregate` unfiltered, and every field — forecast, budget and
actual income alike — was summed the same way.

The diagnosis was exactly right, including why it had stayed hidden: in production
a month still to come holds no transactions, so the two happened to agree. It
only became visible against a dataset with data beyond the boundary, which is the
case nobody thinks to check.

## The fix

The two kinds of figure are summed differently, because they mean different
things:

**Forecast and budget cover the whole period.** A full-year budget is a full
year, including months still to come. Trimming those would understate every
target and make achievement look better than it is — a worse error than the one
being fixed.

**Actual income covers only months that have started.** A month that has not
begun cannot have produced any, whatever happens to be sitting in the table.

```
quarter Q3 FY2025   has_started = False
   actual income summed : 0.00          <- was 107,244.15
   budget summed        : 321,732.45    <- unchanged
```

## Two tests, one for each half

`test_a_period_that_has_not_started_reports_no_income` — at month, quarter and
year grain, a row marked not started reports no income in any of the four actual
fields.

`test_budget_still_covers_the_whole_period` — the other half, so the fix cannot
overreach later. A year's budget must equal the year's budget, not the part of it
that has happened.

Asserting both matters: fixing one by breaking the other would pass a test suite
that only checked the first.

## Install

Replace both files, build, run the suite, restart the workflows, commit, push.

I could not run the suite — my environment has no database. Both files parse, the
change has one call site and it is updated, and the arithmetic is traced above
against the fixture's own shape.

## Still outstanding, and it is not code

`last_completed_loaded: none` — August is not imported, and **August closed in
WinBEAT on 31 August.** Period 136 should be pullable now. That is the largest
remaining gap in what the app can show you, and no further code will close it.
