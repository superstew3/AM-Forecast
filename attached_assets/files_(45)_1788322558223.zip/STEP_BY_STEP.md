# One step at a time

One file: `main.py` -> `app/api/main.py`.

## Where we are

Production is at 19 recorded migrations and still on the old `v_bonus_month`.
The flag is set correctly (`"1"`), the deployment runs the right module
(`app.api.main:app`), and there is no lifespan handler suppressing the startup
hook. All three checks came back clean, and it still did not apply.

So the next thing is not another guess. It is making production able to say what
happened.

## Why the missing log line proved nothing

The startup hook logs through the root logger. Uvicorn does not always capture
that into the deployment log. So "no log line" and "never ran" look identical
from outside, and that ambiguity is what has made this untraceable.

This records the result instead, and reports it on `/api/health`.

## What you will get

```json
"migrations": {
  "auto_migrate_enabled": true,
  "path": "/home/runner/workspace/am_forecast/migrations/versions",
  "files_found": 24,
  "recorded_in_database": 19,
  "outstanding": ["0020_...", "0021_...", "0022_...", "0023_...", "0024_..."],
  "startup": { "ran": true, "auto_migrate": true, "migrated": [], "notes": [] }
}
```

Each field answers one question that has been unanswerable:

- **`startup.ran: false`** — the hook never fired. Something about how the app is
  served is skipping it.
- **`startup.ran: true, auto_migrate: false`** — the flag is not reaching the
  process, whatever the deployment settings say.
- **`startup.ran: true, migrated: []`, five outstanding** — it ran, it was
  enabled, and `pending()` returned nothing. That is a code fault I can read and
  fix directly.
- **`startup.error`** — it threw, and the message says what.
- **`files_found: 0`** — the build is not shipping migrations, and `path` shows
  where it looked.

## Do these in order, one at a time

### Step 1 — install and push

Tell Replit:

> Replace `app/api/main.py`. Run the suite, commit and push. Do not publish.

Wait for it to confirm the suite is green.

### Step 2 — publish

You do this. Schema and code only. **Leave "Copy your development database to
production database" unticked.**

### Step 3 — ask production

```bash
curl -s https://am-forecast.replit.app/api/health | python3 -m json.tool
```

Send me the `migrations` block. That is the whole message; nothing else is
needed.

### Step 4

I will tell you the one thing to do next, based on which of the five cases it is.

## On the database sizes

268MB dev against 74MB production is expected, and production is the healthy one.
Dev has absorbed hundreds of test runs -- match candidates, upload batches,
staging rows, audit records. We cleared 525 junk upload batches from it once and
they have built up again. Production holds your real data and nothing else.

Worth a periodic clean on dev. Not a problem, and not related to this.
