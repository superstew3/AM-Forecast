-- Why is August's indicative bonus N/A when the budget was achieved?
--
-- indicative_bonus is NULL only when forecast_month > the view's cut_month, or
-- when one of its inputs is NULL. July returns a figure and August does not, so
-- something month-dependent is doing it. These four answer which.

\echo === 1. what the calendar thinks today is ===
SELECT reporting_current_month()                    AS current_month,
       (now() AT TIME ZONE 'Australia/Melbourne')::date AS melbourne_today,
       reporting_current_month()
         = date_trunc('month', (now() AT TIME ZONE 'Australia/Melbourne'))::date
                                                    AS function_is_the_real_calendar;

\echo
\echo === 2. the row itself, July beside August ===
SELECT period_month, month_started, expected_income, budget_target,
       actual_income, target_reached, indicative_bonus, bonus_gst_divisor
FROM v_bonus_month
WHERE canonical_manager = 'Liam Thornton'
  AND period_month IN (DATE '2026-07-01', DATE '2026-08-01')
ORDER BY period_month;

\echo
\echo === 3. every input the expression needs, unrounded ===
SELECT b.forecast_month,
       b.original_forecast, b.total_budget,
       a.net_actual_income,
       s.bonus_base_divisor, s.bonus_above_target_rate, s.bonus_gst_divisor
FROM v_monthly_budget b
LEFT JOIN v_actual_month a ON a.canonical_manager = b.canonical_manager
                          AND a.period_month = b.forecast_month
CROSS JOIN reporting_settings s
WHERE b.canonical_manager = 'Liam Thornton' AND s.id = 1
  AND b.forecast_month IN (DATE '2026-07-01', DATE '2026-08-01')
ORDER BY b.forecast_month;

\echo
\echo === 4. has a test fixture left the clock overridden? ===
SELECT pg_get_functiondef('reporting_current_month'::regproc) AS definition;
