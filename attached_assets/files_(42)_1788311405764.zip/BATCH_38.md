# Batch 38 — growth rates, and a bonus to diagnose

Two files to upload: `rebuild.sh` and `DIAGNOSE_BONUS.sql`.

## 1. Why your growth percentages reset — the actual cause

Your agent settled it: **production has never been rebuilt.** Its three users have
three different `password_set_at` timestamps, which is ordinary login activity.
Dev's are all identical to the second — the signature of a rebuild, on 20 August.

So the reset is not `rebuild.sh`. It is **publishing with the "copy dev data to
production" option selected.** Dev's `growth_rate` table holds only the seeded
default; copying it over production replaces every override you have set.

### The fix is a choice at publish time

**When publishing, do not copy dev data to production.** Publish schema and code
only. Production's data is the real book — dev's is a working copy that has been
rebuilt from fixtures repeatedly during this work, and it should never overwrite
the live one.

That is not a code change; it is the option to leave unticked, every time.

### And the fix in the script, which is still worth having

`scripts/rebuild.sh` runs `DROP SCHEMA public CASCADE`, so anything typed into
the app rather than derived from a CSV or a migration is destroyed with it. That
has bitten three times already — July's baseline, August's, the ranking flags —
each fixed by replaying the script that created it. Growth rates were never
added.

Hard-coding today's rates would go stale the first time one changed, so they are
**carried across** instead: dumped before the drop, restored after the seed.

```
growth_rate            per-manager and per-quarter overrides
monthly_target_override
forecast_month_lock
forecast_month_override
manager_alias
```

Whatever is set at the time survives, including settings made long after this
script was written. Restored after the seed so seeded defaults go in first and
your overrides take precedence — the order the application itself applies. A
preserved row whose table changed shape in a later migration is skipped with a
warning rather than aborting the rebuild.

This protects dev, and it protects production if anyone ever rebuilds it.

## 2. Liam's August bonus — one query before I touch anything

`indicative_bonus` is NULL only when the month sits past the view's boundary, or
when one of its inputs is NULL. **July returns a figure and August does not**, so
the cause is month-dependent and there are only a few candidates.

My suspicion is that `reporting_current_month()` returns **July 2026** on that
database, which would make August "future" and null its bonus — and would fit the
pattern exactly. The likeliest reason is the `closed_month` test fixture, which
replaces that function and restores it afterwards; a run that died mid-fixture
would leave the override behind. Dev was rebuilt on 20 August and the suite has
run against it many times since.

Run it and send the output:

```bash
psql "$DATABASE_URL" -f DIAGNOSE_BONUS.sql
```

**Section 4 is decisive.** If `reporting_current_month()` is defined as a
hard-coded date rather than `now() AT TIME ZONE 'Australia/Melbourne'`, that is
the answer — and the fix will include a guard so a fixture can never leave it
overridden again, because a test that can silently change what month the whole
system believes it is has no business being able to fail halfway.

I am not acting on the suspicion. Four of my recent errors came from reasoning
about something I had not read.
