#!/usr/bin/env bash
# Rebuild the database from empty, at the current migration level.
#
#   bash scripts/rebuild.sh
#
# Uses $DATABASE_URL, which Replit sets. Replit's Postgres is hosted, so
# dropdb/createdb are unavailable -- the schema is dropped and recreated in
# place instead, which has the same effect.
#
# Source files are found by content, not by name: point CSV_DIR at the directory
# holding them and the detector works out which is which. Hard-coded filenames
# from one export are what made the last dataset change so painful.
#
#   CSV_DIR=fixtures bash scripts/rebuild.sh
set -euo pipefail

DSN="${DATABASE_URL:-${DSN:-}}"
if [ -z "$DSN" ]; then echo "No DATABASE_URL or DSN set."; exit 1; fi
CSV_DIR="${CSV_DIR:-fixtures}"
[ -d "$CSV_DIR" ] || { echo "No such directory: $CSV_DIR  (set CSV_DIR)"; exit 1; }

echo "==> Identifying source files in $CSV_DIR"
mapfile -t FOUND < <(CSV_DIR="$CSV_DIR" python3 - <<'PY'
import os, sys, glob
sys.path.insert(0, ".")
from app.importers import detect
sales, renewals = [], []
for p in sorted(glob.glob(os.path.join(os.environ["CSV_DIR"], "*.csv"))):
    try:
        d = detect(p)
    except Exception:
        continue
    if not d.importable:
        continue
    (sales if d.file_type == "sales" else renewals if d.file_type == "renewals" else []).append(p)
print(sales[0] if sales else "")
print("\n".join(renewals))
PY
)
SALES="${FOUND[0]:-}"
RENEWALS=("${FOUND[@]:1}")
[ -n "$SALES" ] && echo "    sales:    $(basename "$SALES")" || echo "    sales:    (none found)"
for r in "${RENEWALS[@]}"; do echo "    renewals: $(basename "$r")"; done
[ ${#RENEWALS[@]} -gt 0 ] || { echo "No renewals file found. Nothing to build."; exit 1; }

# --- preserve what an operator set by hand -----------------------------------
#
# A rebuild drops the schema, so anything typed into the app rather than derived
# from a CSV or a migration is destroyed. That has now bitten three times: July
# and August's baselines, the ranking flags, and growth percentages -- somebody
# sets a manager to 10%, a rebuild happens, and everyone is quietly back on the
# default with nothing to say why.
#
# The first two are restored by replaying the scripts that created them. That
# does not work for growth rates and month overrides: those are decisions, and
# hard-coding today's values here would go stale the first time one changed.
#
# So they are carried across instead -- dumped before the drop, restored after
# the migrations and seed. Whatever is set at the time survives, including
# settings made after this script was written.
PRESERVE=(growth_rate monthly_target_override forecast_month_lock
          forecast_month_override manager_alias)
CARRY="$(mktemp -t am_forecast_carry.XXXXXX.sql)"
trap 'rm -f "$CARRY"' EXIT

echo "==> Preserving operator settings"
: > "$CARRY"
for t in "${PRESERVE[@]}"; do
    exists=$(psql "$DSN" -X -qtA -c \
        "SELECT to_regclass('public.$t') IS NOT NULL")
    if [ "$exists" = "t" ]; then
        n=$(psql "$DSN" -X -qtA -c "SELECT count(*) FROM $t")
        if [ "$n" -gt 0 ]; then
            pg_dump "$DSN" --data-only --table="public.$t" \
                    --no-owner --no-privileges >> "$CARRY" 2>/dev/null \
                && echo "    $t: $n rows carried"
        fi
    fi
done

echo "==> Dropping and recreating the schema"
psql "$DSN" -X -q -v ON_ERROR_STOP=1 -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"

echo "==> Migrations"
for f in migrations/versions/*.sql; do
    psql "$DSN" -X -q -v ON_ERROR_STOP=1 -f "$f" > /dev/null
    echo "    $(basename "$f")"
done

echo "==> Seed"
python3 -m app.seed.load_seed "$DSN" > /dev/null

if [ -n "$SALES" ]; then
    echo "==> Sales: $(basename "$SALES")"
    python3 scripts/import_cli.py "$DSN" prepare "$SALES" --user=sam > /dev/null
    B=$(psql "$DSN" -X -qtA -c "SELECT id FROM upload_batch WHERE file_type='sales' AND status='pending' ORDER BY id DESC LIMIT 1")
    python3 scripts/import_cli.py "$DSN" accept "$B" --user=sam --force > /dev/null
fi

# The NEWEST renewals extract only. Loading older ones as well is wrong: a newer
# snapshot supersedes an open month, so bulk-loading the history ends with only
# the last file's months present and everything earlier silently gone. Tested --
# it wiped July. Months earlier than the newest extract are established
# deliberately instead, via establish_*_baseline.sql, because an extract taken
# during or after a month has already lost whatever renewed in it.
echo "==> Renewals, newest extract only"
DSN="$DSN" RENEWALS="$(printf '%s\n' "${RENEWALS[@]}")" python3 - <<'PY'
import datetime as dt, os, sys
import psycopg2, polars as pl
sys.path.insert(0, ".")
from app.importers import prepare, accept
from app.importers.normalise import parse_date

def earliest_expiry(path):
    vals = pl.read_csv(path, infer_schema_length=0)["ExpiryDate"].drop_nulls().to_list()
    parsed = []
    for v in vals:
        try:
            parsed.append(parse_date(v))
        except Exception:
            pass
    return min(parsed) if parsed else dt.date.min

conn = psycopg2.connect(os.environ["DSN"])
paths = sorted(os.environ["RENEWALS"].split("\n"), key=earliest_expiry)
for path in paths[-1:]:
    s = prepare(conn, path, "sam")
    all_months = sorted({mc.forecast_month for mc in s.coverage.months}) if s.coverage else []

    # Only months that began AFTER this file was pulled. A pending-renewals
    # report lists what has not yet transacted, so for the month it was pulled in
    # -- and any month before it -- the file is already missing whatever renewed.
    # Establishing those months from it sets a target short by however much of the
    # month had already gone, and under the current-month freeze that is then
    # locked in permanently.
    #
    # The pull date is inferred the same way the importer infers snapshot
    # recency: from the earliest expiry the file contains, since a pending report
    # cannot hold a renewal that has already happened.
    pulled = min(all_months) if all_months else None
    months = [m for m in all_months if pulled is None or m > pulled]
    withheld = [m for m in all_months if m not in months]

    accept(conn, s.batch_id, "sam", confirmed_months=months)
    conn.commit()
    print(f"    {os.path.basename(path)}: pulled ~{pulled}, established {len(months)} months"
          f" ({months[0]} to {months[-1]})" if months else
          f"    {os.path.basename(path)}: no month postdates this extract")
    if withheld:
        print(f"      withheld (extract does not predate them): "
              f"{', '.join(str(m) for m in withheld)}")
        print(f"      establish these deliberately via establish_*_baseline.sql")
if len(paths) > 1:
    skipped = ", ".join(os.path.basename(p) for p in paths[:-1])
    print(f"    not loaded (older extracts): {skipped}")
    print("    establish earlier months deliberately, not by loading these")
PY

# July and August 2026 come from figures supplied directly, not from a CSV in
# CSV_DIR: no extract covers either month completely (see the comments in
# establish_july_2026_baseline.sql and set_month_forecast_from_file.py). A
# rebuild that skips these two steps produces a database that looks complete
# but silently has no forecast for either month.
# Restored after the seed so the seed's defaults are in place first and these
# override them, which is the same precedence the application applies.
if [ -s "$CARRY" ]; then
    echo "==> Restoring operator settings"
    # ON_ERROR_STOP is deliberately off: a preserved row whose table changed
    # shape in a later migration should be skipped with a warning, not abort a
    # rebuild that is otherwise fine.
    psql "$DSN" -X -q -f "$CARRY" 2>&1 | grep -i "error" | head -5 || true
    for t in "${PRESERVE[@]}"; do
        n=$(psql "$DSN" -X -qtA -c "SELECT count(*) FROM $t" 2>/dev/null || echo 0)
        [ "$n" -gt 0 ] && echo "    $t: $n rows"
    done
fi

echo "==> July 2026: establishing from supplied figures"
psql "$DSN" -X -q -v ON_ERROR_STOP=1 -f scripts/establish_july_2026_baseline.sql > /dev/null

echo "==> August 2026: establishing from the 14 July extract"
JULY14=$(find "$CSV_DIR" -maxdepth 1 -iname '*20260714*Renewals*' -print -quit)
[ -n "$JULY14" ] || { echo "No 14 July renewals extract found in $CSV_DIR (looked for *20260714*Renewals*)."; exit 1; }
python3 scripts/set_month_forecast_from_file.py "$DSN" "$JULY14" --month=2026-08-01 \
    --reason="14 July extract; August had not yet renewed"

echo "==> Users"
python3 scripts/create_users.py "$DSN"

echo
echo "Rebuilt. Checking:"
bash scripts/check_state.sh
