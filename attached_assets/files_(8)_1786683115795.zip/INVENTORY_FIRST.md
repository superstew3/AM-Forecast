# Stop. Run the inventory before anything else.

## Two corrections to what I sent you

**1. `preflight_0016.sh` was broken, and the break was mine.**

It queried `forecast_policy.primary_assoc_comm_sum` — a column that migration
0016 *creates*. So on any database that has not had 0016 applied, which is every
database the script is written for, it died before reporting anything. The error
you saw is a bug in my script, not a finding about your schema.

The corrected version is attached. Every check now tests whether a column exists
before reading it.

**2. `forecast_policy` having no `primary_assoc_comm_sum` is correct and
expected.**

CATCHUP.md says so explicitly — that column does not exist before 0016, which is
exactly why the backfill in step 4 is mandatory. The broken preflight made a
normal, documented condition look like a schema mismatch. Nothing is wrong there.

## The real finding, and I cannot explain it from here

`sales_transaction` having **zero rows** contradicts your earlier `check_state.sh`
run, which reported outlook rows in prior financial years. Prior-year outlook
comes from actuals, and actuals come from `sales_transaction`. Both cannot be
true of the same database at the same time.

I tested whether the failed test run destroyed the sales data. **It did not** —
299 rows before, 299 after, across a run with 23 failures and 17 errors. So that
is not the explanation, and I am not going to guess at another one.

## Run this and send me the whole output

```bash
bash scripts/inventory.sh
```

No expected values, no assumptions, nothing that fails when something is absent.
It reports:

- which database the connection actually reaches, by name, host and port
- the migration level inferred from schema markers
- row counts for every populated table, and which normally-populated tables are
  empty
- **the full upload history: every batch, its status, and who rolled it back**
- the reporting cut-off and who set it
- whether outlook figures come from actuals or from forecast, per quarter

The upload history is the one that matters. If the original sales batch was
rolled back, it will say so and name who did it. If it was never loaded, it will
not be there at all.

The database name, host and port matter too. If `DATABASE_URL` resolves
differently in different Replit contexts, `check_state.sh` and
`preflight_0016.sh` may have run against two different databases — which would
explain the contradiction completely.

## Do not

- Do not apply 0016 or 0017.
- Do not import anything to "fix" the empty sales table.
- Do not restore a backup.

Not until the inventory says what is actually there. Report only.
