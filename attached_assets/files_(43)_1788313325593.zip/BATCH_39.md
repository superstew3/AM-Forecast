# Batch 39 — getting five migrations into production, safely

Two files: `app/bootstrap.py` and `scripts/rebuild.sh`.

## What your agent found, and why it matters

**Production is five migrations behind** — recorded at 0019, missing 0020 to
0024. Its `v_bonus_month` still reads the frozen `cut_off_date` of 2026-07-31,
which is why August's bonus reads N/A while July's does not.

**Dev's `schema_migration` is empty** — not because the migrations are unapplied,
but because `rebuild.sh` applied each one with a plain `psql -f` and recorded
none of them. Your agent checked the actual objects rather than the row count,
which was the right call and is how this was caught.

**Replit's schema differ reports no difference** while a direct query shows
production plainly behind. I cannot reconcile that either. The most likely
explanation is that the differ compares tables and ignores views — 0020 to 0024
are view-only, which would make every one of them invisible to it, and would
explain how production drifted five behind while publishes kept succeeding.

I am not proposing we rely on it either way.

## The route that does work

Production's `schema_migration` has 19 rows. That is exactly the state
`bootstrap.migrate()` is built for: it applies the files not yet recorded, each
in its own transaction, behind an advisory lock, and records each as it goes.

It is the application's own supported mechanism, not a workaround, and it needs
no DDL from the agent.

**But it was not safe to switch on yet**, because of a hole this batch closes.

## The hole

`pending()` reconciles only when `schema_migration` does not EXIST. Dev's exists
with zero rows, so every file reads as un-applied — and auto-migrate there would
replay 0001 onward over a populated schema.

That is the same fault as the hardcoded 0015 watermark that silently dropped
`bonus_gst_divisor`, reached through a different door: one asked the wrong
question about WHICH files were applied, this one about WHETHER anything had been
recorded at all.

**`pending()` now treats an empty table exactly as a missing one.**

**`rebuild.sh` now records each migration it applies**, so a rebuilt database
says truthfully what it holds and the tracking table means the same thing
everywhere.

Traced across every state, since I cannot run it:

```
state                                            would apply
dev after rebuild (table empty, schema built)        nothing
production today (19 recorded)               5 files: 0020..0024
a genuinely new database                    24 files: 0001..0024
dev with the rebuild fix (24 recorded)               nothing
```

## Install, in this order

**1.** Replace `app/bootstrap.py` and `scripts/rebuild.sh`. Run the suite,
commit, push.

**2.** Publish, so production has the new `bootstrap.py`. Schema and code only —
**do not copy dev data to production**, or the growth rates reset again.

**3.** Then, and only then, set `AM_FORECAST_AUTO_MIGRATE=1` on the production
deployment and restart it.

On startup it will apply 0020 to 0024 and record them. Watch the logs for the
five filenames.

**4.** Confirm against production:

```sql
SELECT count(*) FROM schema_migration;                              -- expect 24
SELECT pg_get_viewdef('v_bonus_month', true) LIKE '%cut_off_date%'; -- expect false
```

**5.** Turn `AM_FORECAST_AUTO_MIGRATE` back off once confirmed. Leaving startup
DDL on is not something to keep permanently; it is on for one restart to close a
gap.

## What changes for you

Liam's August bonus appears. The bonus tracker's pace uses completed months.
Projections scale by pace rather than a month count. New Business gets its month
grain and counts — that page may be erroring on production right now, since it is
running new code against a schema without `new_business_count`.

## If step 3 fails

The migrations apply one file per transaction, so a failure rolls back that file
alone and the ones before it stand. Send the log. Do not re-run it repeatedly.
