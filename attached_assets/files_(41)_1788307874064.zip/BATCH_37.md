# Batch 37 — my tests, written against a shape I did not read

One file: `tests/test_stage13_boundary.py`.

The fix in `reporting.py` from batch 36 is correct and already in. This is only
the tests I wrote badly around it.

## What was wrong

Every monetary field in `/api/managers` is a `Money` object:

```json
{"value": "69049.90", "available": true, "reason": null}
```

I wrote `Decimal(str(v))` against it, which produces
`Decimal("{'value': ...}")` and throws. Your agent diagnosed it exactly.

**And a second fault it did not need to find**: I used `absolute_return_income`,
which this endpoint calls `return_income`. `.get()` returned `None`, the
assertion passed on nothing, and the test would have looked like it was checking
a field it never touched. A wrong name there is worse than a crash, because it is
silent.

**And a third, latent**: `test_year_to_date_includes_the_month_under_way` did
`float(r.get("net_actual_income") or 0)` on the same wrapper. It passes today
only because it skips while the month under way has no transactions — so it would
have broken the moment the data it exists to test arrived. A test that fails when
its subject appears is worse than no test.

## What I did about it

**One helper, `amount()`,** so the shape is read in one place instead of from
memory in five. It handles all four cases:

```
Money, populated       -> Decimal('69049.90')
Money, unavailable     -> None            <- never zero; that is the whole point
raw number             -> Decimal('12345.67')
absent                 -> None
```

**Every field name cross-checked against the model by parsing it**, not by
reading it and trusting myself:

```
field                     in model   type
actual_new_business         True     Money
canonical_manager           True     str
has_started                 True     bool
net_actual_income           True     Money
positive_actual_income      True     Money
return_income               True     Money
total_budget                True     Money
```

**An assertion that the field exists** before checking its value, so a future
rename fails loudly instead of passing vacuously.

**The other two test files checked as well.** `test_stage12_review.py` reads
database columns only. `test_stage11_performance.py` reads
`/api/performance`, which returns raw view rows with no `Money` wrapper — zero
references to it in `performance.py` — so its plain-number reads are right. Both
correct as they stand.

## Install

Replace `tests/test_stage13_boundary.py`. Run the suite, commit, push. No app
change, no restart.

I still cannot run the suite here — no database in my environment — which is
exactly why I checked the model by parsing it this time rather than trusting
recall. If it still fails, send the traceback.

## The one thing left, and it is not code

`last_completed_loaded: none`. **August closed in WinBEAT on 31 August**, so
period 136 should be pullable now. That is the largest remaining gap in what the
app can show, and no further code will close it.
