# Batch 35 — why the August upload vanished

Eight files. Six API modules, one fixture, one new test file. No migration.

**This supersedes the earlier batch 35 files. Take all eight.**

## What happened

The upload worked. The rows went into `sales_transaction`. Then every reporting
surface threw them away.

Migration 0020 moved every **view** onto the calendar. **Eight places in the API
were missed** and kept deriving their month boundary from
`reporting_settings.cut_off_date`, still reading 2026-07-31. So the views knew
August had started and the endpoints did not — and the endpoints are what the
pages call.

The worst of them, in `reporting.py`:

```python
if period == "ytd":
    rows = [r for r in rows if r["period_month"] and r["period_month"] <= cut]
```

A Python filter discarding every row after the boundary before aggregating. An
accepted import silently removed from the answer, with a reporting setting
deciding whether an upload was visible at all.

Nothing errored. The numbers simply did not move.

## The eight

| Where | What it broke |
|---|---|
| `reporting.py` `_MANAGER_SQL` | the manager query's cut CTE |
| `reporting.py` ~line 282 | **dropped August rows before aggregating** |
| `analytics.py` `_cut_month()` | the manager matrix |
| `manager_detail.py` | blanked every month after the boundary |
| `operations.py` | review queue timing classification |
| `settings.py` `/api/periods` | the year selector on every page |
| `main.py` health check | asked whether the cut-off month was loaded |
| `main.py` `/api/base-position` | **the one my own sweep missed** |

## The guard caught what I did not

I verified my fix by grepping for `date_trunc('month', cut_off_date)` and
declared the tree clean. The test I wrote in the same batch also checks
`au_financial_year(cut_off_date)` — and found `main.py:185`, which derives a
financial YEAR from the cut-off rather than a month.

So the guard was stricter than the sweep that preceded it, and caught a real miss
I had already claimed was fixed. That is the argument for writing it that way.
Now clean on both patterns.

## The four dashboard failures were real too

`closed_month` in `conftest.py` simulated a completed month by rolling
`cut_off_date` back. Once the endpoints stopped reading it, that did nothing — so
four tests were comparing a full-year total against a boundary nothing observed.
The fixture was driving a mechanism retired underneath it.

It now overrides `reporting_current_month()` instead, which is the one thing every
view, endpoint and the importer all consult, so moving it moves the whole system
together. The original definition is captured with `pg_get_functiondef` and
restored afterwards. Committed rather than held in a transaction, because the API
runs on its own connection and would not otherwise see it. The function is
`STABLE`, so the override takes effect per statement with nothing cached.

## My mistake, plainly

I identified this in batch 28 — *"48 references in application code across nine
files"* — fixed the upload blocker and the hard-coded years, wrote in the notes
that the cut-over was half done, and moved on. Three weeks of income invisible
because of a job I had already diagnosed and left unfinished.

## Install

Replace all eight, then:

```bash
cd web && npm run build
cd .. && AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Expect the baseline plus five, with the four `test_stage5_dashboard` failures
cleared by the fixture change.

**I could not run the suite for this batch** — the database in my environment was
lost partway through, so the fixture rewrite is reasoned from the code and not
executed. If anything still fails, send the traceback.

Then **restart the workflows** — these are API modules, so the running process
serves the old code until it does. Then publish.

## Check afterwards

August income should appear on the business page, in the account-manager figures
and in the month-by-month grids, **without re-uploading anything**. The rows have
been there the whole time.
