# Batch 35 — why the August upload vanished

Seven files: six API modules and one new test file. No migration.

## What happened

The upload worked. The rows went into `sales_transaction`. Then every reporting
surface dropped them.

Migration 0020 moved every **view** onto the calendar. **Seven places in the API
were missed** and kept deriving their month boundary from
`reporting_settings.cut_off_date`, which still reads 2026-07-31. So the views knew
August had started and the endpoints did not — and the endpoints are what the
pages call.

The worst of them, `reporting.py`:

```python
cut = fetch_one("""SELECT date_trunc('month', cut_off_date)::date AS m ...""")
if period == "ytd":
    rows = [r for r in rows if r["period_month"] and r["period_month"] <= cut]
```

A Python filter that discards every row after the boundary before aggregating.
An accepted import, silently removed from the answer, with a reporting setting
deciding whether an upload was visible at all.

Nothing errored. The numbers simply did not move, which is the worst way for
software to be wrong.

## The seven

| Where | What it broke |
|---|---|
| `reporting.py` `_MANAGER_SQL` | the manager query's own cut CTE |
| `reporting.py` line ~282 | **dropped August rows before aggregating** |
| `analytics.py` `_cut_month()` | the manager matrix |
| `manager_detail.py` | blanked every month after the boundary in the grid |
| `operations.py` | review queue timing classification |
| `settings.py` `/api/periods` | the year selector on every page |
| `main.py` health check | asked whether the cut-off month was loaded |

All now read `reporting_current_month()`. The cut-off is still **reported** on the
settings page and in `Meta` — that is fine, it is a record. It no longer decides
anything anywhere.

`main.py`'s check is renamed `last_completed_month_is_loaded` and re-pointed. It
was answering a question nobody was asking.

## My mistake, plainly

I identified this in batch 28: *"48 references in application code across nine
files"*. I fixed the upload blocker and the hard-coded years and left the month
boundaries, then wrote in the notes that the cut-over was half done — and moved on
to the next thing. Three weeks of August income was invisible because of a job I
had already diagnosed and not finished.

## The guard

`tests/test_stage13_boundary.py`. Five tests, one of them deliberately a grep.

A behavioural test cannot catch this class of fault: while the cut-off happens to
sit in the right place, the endpoints and views agree, and the bug only appears in
the month after somebody forgets to move a setting that is meant to do nothing.

So one test reads the source and fails if a month boundary is derived from
`cut_off_date` again. Verified both ways: with the original bug reintroduced it
finds `reporting.py:292`; on the fixed tree it finds nothing.

The other four assert the symptom directly — the API and the views agree on the
current month, the year selector follows the calendar, a month with transactions
loaded appears in the manager figures, and year to date includes the month under
way.

## Install

```bash
cd web && npm run build          # no frontend change, but confirms nothing broke
cd .. && AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Expect the baseline plus five. **Restart the workflows** — these are API modules,
so the running process serves the old code until it does. Then publish.

## Check afterwards

The August income should appear on the business page, in the account-manager
figures and in the month-by-month grids, without re-uploading anything. The rows
have been there the whole time.

If it still does not appear, send me `/api/managers?period=ytd` and I will look
again — but this is the filter that was removing it.
