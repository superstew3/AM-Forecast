# The $640, fixed at source

## What it was

`scripts/set_month_forecast_from_file.py` carried its own `is_excluded()`,
commented *"Mirror the seeded exclusion rules for renewals."* It was not a
mirror. The `exclusion_rule` table holds **seven** renewals rules; the copy
implemented five:

| Seeded rule | In the copy? |
|---|---|
| Renewals manager is CAM HIGHVIEW | yes |
| Renewals group is CAM HIGHVIEW (`Group1Abbrev`) | **no** |
| Primary associate contains HIGHVIEW | yes |
| Primary associate contains CAMHIGH | yes |
| Primary associate contains **SIG HIGH** | **no** |
| Secondary associate contains HIGHVIEW | yes |
| Secondary associate contains CAMHIGH | yes |
| Secondary associate contains **SIG HIGH** | **no** |

One August policy worth exactly $640.00 matches `SIG HIGH` and so passed the copy
while failing the real rules. A month pinned by this script therefore disagreed
with the same month imported normally — silently, in the one script whose entire
job is establishing a baseline nobody can correct afterwards.

It has been wrong since it was written. Anything ever pinned with it carries the
same defect, including July in the original build sequence.

## The fix

The script now loads the rules from the database through `ExclusionEngine`, the
same class the importer uses:

```python
engine = ExclusionEngine.load(cur, "renewals")
rows = [r for r in read_month(path, month) if engine.check(r) is None]
```

There is now exactly one implementation of exclusion in the codebase. A rule
added through settings takes effect in the pin script too, which is what putting
the rules in a table was for.

Checked the rest of `scripts/` for other hand-rolled copies. This was the only
one.

## Verified

```
August 2026: 538 policies, $291,970.36 (replaced 538 rows). Pinned against later snapshots.
```

Was 539 policies and $292,610.36. Suite still 237 passed, 7 skipped on a full
rebuild.

## Re-apply

The corrected script is inside the re-packaged `am_forecast_app.tar.gz`.

```bash
tar xzf am_forecast_app.tar.gz
python3 scripts/set_month_forecast_from_file.py "$DATABASE_URL" \
    fixtures/McMc_Partners_20260714_Renewals_Pending_Summary.csv \
    --month=2026-08-01 \
    --reason="14 July extract: last file pulled before August began"
```

Expect **538 policies, $291,970.36**. It replaces the month wholesale, so
re-running over the current 539-policy figure is safe and is the correction.

## Ignore the reconcile verdict for August

`reconcile_month_baseline.sql` will still report STOP and 169 unresolved rows.
Both are wrong, and both are faults in that script rather than in the data.

It looks for a *snapshot* uploaded before the month began. A pin is not a
snapshot — no `upload_batch` row exists — so it finds nothing and says STOP. It
is asking the wrong question about a month established the way you asked.

The 169 "unresolved" rows join baseline rows against `forecast_policy`, which
holds only the newer extract. Those policies were pending on 14 July and had
renewed by the time the newer file was pulled, so they are absent from it by
definition. They are the most important rows in August, not the suspect ones:
$44,258.99 of genuine expected income that the newer file would have lost.

That script needs rewriting to understand pinned months. Until then, do not
treat its August verdict as meaningful.
