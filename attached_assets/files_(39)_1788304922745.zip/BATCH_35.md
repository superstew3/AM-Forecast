# Batch 35 — one rule, applied everywhere

**Ten files. Supersedes every earlier batch 35 drop.**

## The root cause, stated once

Every fault in this batch — the vanished August upload, my broken first fix, and
all three remaining test failures — is the same thing: **two different questions
answered by one value.**

| Question | Governs | The month under way |
|---|---|---|
| Has this month **started**? | whether income is **shown** | included |
| Has this month **finished**? | whether anything is **scored** | excluded |

August income belongs on the page the day it is imported: it has been earned.
Nothing about August should be measured against a whole month's target: it is
three weeks old.

The stored cut-off used to answer both, badly. Then I pointed everything at
`reporting_current_month()`, which answered "started" for both — so income
reappeared and comparisons became wrong. Then at the completed month, which
answered "finished" for both — so comparisons became right and income vanished
again.

`core.py` now exposes `current_month()` and `last_completed_month()`, named for
the question each answers, and every call site takes the one it means:

```
reporting.py  YTD row filter      -> started   August income appears
reporting.py  budget_to_date      -> judged    not measured against a part month
analytics.py  manager matrix      -> started   grid shows the month under way
analytics.py  year-over-year YTD  -> judged    like for like
manager_detail.py future test     -> started   current month not blanked
```

`analytics.py` had one variable serving both inside a single function, which is
why the matrix and the comparison could not both be right.

## The three remaining failures

**1. A guard that checked something else.** `test_01` read
`last_completed_month_is_loaded` (false — August is not loaded), then went and
checked the load state of the CUT-OFF month (July, full), so it did not skip and
asserted base state against a position the endpoint had just said was not base
state. A guard checking a different condition from the one it guards is worse
than none: it looks like the case was considered. It now asks the question it
just read.

**2. A comparison scoped two ways.** `test_manager_matrix_totals_match_the_views`
filtered its expected sum by the stored cut-off while the endpoint scopes by the
calendar. It agreed only while those happened to coincide. Now both use
`reporting_current_month()`.

**3. A fixture with no room.** `closed_month` anchored on the earliest month with
actuals — May 2025, whose next month is June 2025, the last month of FY2024. No
month remained in that year to assert was future, so the test failed on the shape
of the dataset.

It now picks the earliest month that has actuals **and leaves two more months in
its own financial year**. On your data that is July 2025: July completed, August
under way, and ten months still to come. One completed, one in progress, one
future — which is exactly what these tests exist to tell apart.

## Checked, since I could not run it

My environment lost its database, so: every changed file parses; the boundary
guard reports clean across `app/api`; no removed helper is still referenced; and
the fixture's month selection is traced against your real data shape.

Numbers rather than assertions:

```
anchor      2025-07-01  (FY2025)
pretend now 2025-08-01  -> July completed, August in progress
future months available in that financial year: 10
```

## Install

Replace all ten, build, run the suite, restart the workflows, publish.

If anything still fails, send the traceback. Your agent has been right on every
one of these and I would rather read it than guess again.

## One operational note

`/api/base-position` correctly reports `last_completed_month_is_loaded: false`.
Today is 2 September 2026 and your actuals stop at 31 July, so August — now a
completed month — is missing.

**August has closed in WinBEAT.** Period 136 should be available now, which was
not true when we last discussed it. Pulling it would fill the gap the test is
skipping over, and is the single thing that would most improve what the app shows.
