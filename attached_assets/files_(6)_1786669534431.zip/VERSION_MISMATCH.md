# Read this before applying anything further

## Your Replit project is running older code than the zip you sent me

Three of the failures reported back are not three problems. They are one: the
files in the repl are behind `am_forecast.zip`. Each of the three is a file whose
newer version already fixes exactly what failed.

| Failure | What the repl has | What the zip has |
|---|---|---|
| `ImportError: cannot import name 'sales_expected' from 'app.validation'` | no such function | `app/validation.py` line 51 defines `sales_expected` |
| `test_partial_years_are_flagged` — `KeyError: 2024` | `assert by_year[2024]["coverage_status"] == "partial"` | asserts no specific year, with the comment *"Naming particular years tied this to one export"* |
| `test_no_bonus_below_target` — `AssertionError: assert []` | bare `assert below` | `if not below: pytest.skip("no started quarter is below target in this dataset")` |

Three for three. Someone already fixed all three in the zip, and the repl never
received them.

**This matters more than the failures themselves.** My nine replacement files
landed on top of an older codebase, so the project is now a mix of two versions.
That is worse than being consistently on either one.

## What to do

**Do not** patch these three by hand. Reconcile the versions first.

### Step 1 — find out how far behind the repl is

Run this in the Replit shell and report the output:

```bash
echo "--- validation.py ---"
grep -c "def sales_expected" app/validation.py || echo "MISSING"
echo "--- migrations present ---"
ls migrations/versions/ | tail -3
echo "--- 0016 / 0017 applied to the database? ---"
psql "$DATABASE_URL" -X -qtA -c "SELECT to_regclass('forecast_month_lock') IS NOT NULL AS lock_table, to_regclass('forecast_month_coverage') IS NOT NULL AS coverage_table"
echo "--- primary associate income basis in use? ---"
psql "$DATABASE_URL" -X -qtA -c "SELECT count(*) FROM information_schema.columns WHERE table_name='sales_transaction' AND column_name='gross_income'"
echo "--- stage 6 test version ---"
grep -c "Naming particular years" tests/test_stage6_longevity.py || echo "OLD VERSION"
echo "--- stage 8 test version ---"
grep -c "no started quarter is below target" tests/test_stage8_bonus.py || echo "OLD VERSION"
echo "--- anything modified in the repl recently ---"
find app tests scripts migrations -name "*.py" -o -name "*.sql" | xargs ls -lt 2>/dev/null | head -20
```

### Step 2 — report, do not act

Send that output back before changing anything else. In particular, report **any
file in the repl that looks like later work not present in the zip** — the zip
may not be the newest state of everything, and nothing should be overwritten
blind.

## Separately: the fixture filename problem is fixed

Replace `tests/conftest.py` with the version supplied alongside this file.

The suite no longer looks for two hard-coded filenames. It finds the sales and
renewals exports in `AM_FORECAST_FIXTURES` **by content**, using the
application's own detection routine — the same one the upload screen uses. Your
`fixtures/Sales_Transaction_List_25-26.csv` and
`fixtures/Renewals_Pending_Summary_-_now-june2027.csv` will be found as they are.

**Do not rename them.** They are not the August extract under a different name;
they are different files covering different periods. Renaming would make the
tests derive expectations from data the database was not built from.

Two further behaviours were added:

- Where a directory holds more than one export of the same type, the **newest
  wins**, judged from file contents — earliest expiry for renewals, latest
  transaction for sales. Sorting by name picked a months-old extract sitting
  beside the current one, which is the same failure mode as the April file that
  once wiped August's forecast.
- A missing export now stops the run once with a message naming the directory
  and what is missing, instead of scattering `FileNotFoundError` through thirty
  tests and seventeen fixtures.

Verified against three directory layouts including yours: 237 passed, 7 skipped
in each, with no renaming.
