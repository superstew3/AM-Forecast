# Batch 34 — all five review findings

Seven files. One migration, two seed modules, three test files, one page.

| File | Destination |
|---|---|
| `0024_remove_unused_views.sql` | `migrations/versions/` (new) |
| `seed_data.py` | `app/seed/seed_data.py` |
| `load_seed.py` | `app/seed/load_seed.py` |
| `test_stage1.py` | `tests/test_stage1.py` |
| `test_stage8_bonus.py` | `tests/test_stage8_bonus.py` |
| `test_stage12_review.py` | `tests/test_stage12_review.py` (new) |
| `Budget.tsx` | `web/src/pages/Budget.tsx` |

## 1. The seed stopped at FY2026-27

`forecast_baseline` is INNER JOINed by `v_baseline_usable`, so a month with no
row does not fall back to a default -- it disappears from every view built on it.
The seed generated rows for FY2025-26 and FY2026-27 only.

**From 1 July 2027 a rebuilt database would have had no baselines at all**, and
those months would simply have stopped appearing, with nothing to say why.

The two historical functions stay as they are: they record what actually happened
-- a legacy dashboard for part of it, a snapshot for the rest, and the managers
each did not cover. `later_baselines()` now generates a plain complete baseline
for every year after them, running to one year ahead of today so next year's
forecast is covered before it arrives.

```
as at 2026-08-19: 36 baselines, 2025-07-01 to 2028-06-01
as at 2027-09-01: 48 baselines, 2025-07-01 to 2029-06-01
as at 2030-03-01: 72 baselines, 2025-07-01 to 2031-06-01
```

## 2. The fifth hand-written copy of the exclusion rules

`test_stage1.py` carried `upper(source_manager) <> 'CAM HIGHVIEW'` in its SQL.
After the pin script, two test helpers and a verification script, this was the
fifth. It now reads the manager from `exclusion_rule`.

A rule restated in a test is worse than one restated in code: it goes green
against its own copy while the real rules drift, so the drift is not merely
unnoticed, it is actively vouched for.

## 3. A hard-coded 7.5% in the Budget page

Two `?? 0.075` fallbacks. If the setting were ever absent the form offered 7.5%
as though it were the current rate, and saving would write a number nobody had
chosen -- a hard-coded rate reintroduced through the interface, which is where
most of those exclusion copies came from too.

The field now starts empty and Save is disabled until a rate is typed.

## 4. The review workflow had no test

Four endpoints that write allocations and therefore change reported income --
the largest untested surface in the application, and the one where a regression
would be most expensive: a wrong allocation moves money between managers while
every total downstream still reconciles.

Seven tests, asserting guarantees rather than figures. The one that matters:
**an apportionment cannot exceed its transaction.** Splitting is dividing a
figure, not multiplying it; over-allocation would inflate one manager without
reducing anybody else, and nothing would flag it. Verified the endpoint refuses
it and that allocations never exceed the source.

Also: every filter answers, "all" really is the union of the others, a viewer is
refused, a decision without a reason is refused, and every recorded decision
names its reviewer.

## 5. Three views nothing read

`v_prior_year_comparison`, `v_manager_transfer_detail`,
`v_budget_performance_quarter`. Each verified unreferenced by any endpoint,
script, test, page or other view before dropping. Applied: 40 views to 37, no
cascades.

A view that looks authoritative and is maintained by nobody is a trap. This
codebase has already shown what happens when two things that look equivalent
disagree.

## Three of my own mistakes, found by running it

The new tests failed first time because I wrote field names from memory:
`allocated_amount` for `allocated_income`, `decided_by` for `reviewer`, and
`amount` for `allocated_income` in the splits payload. Read the shapes, corrected.

And `test_projection_is_reported_separately_from_earned` failed on correct
behaviour: `target_reached` can be true before any month has closed, and the
bonus is null there because there is nothing to pay against yet. The test now
requires a completed month before asserting a bonus was earned.

## Install

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/versions/0024_remove_unused_views.sql
cd web && npm run build
cd .. && AM_FORECAST_FIXTURES=fixtures pytest tests/ --dsn "$DATABASE_URL"
```

Expect the baseline plus seven, so around **264 passed**. Commit and push. No
restart needed -- no route or API surface change.

## What remains

**Period controls on five pages** -- Business, AllManagers, ManagerDetail,
ForecastHistory, ManagerIndex. Consistency, not correctness.

**Six endpoints still untested** -- `/auth/events`, `/auth/me`, `/bonus/{manager}`,
`/budget/locks`, `/budget/monthly-override`, `/data-quality/{indicator}`.

**The WinBEAT date-range question**, still open.
