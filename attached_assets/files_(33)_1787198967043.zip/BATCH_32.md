# Batch 32 — the projection was backwards for two managers

One file: `migrations/versions/0023_project_by_pace.sql`.

## What was wrong

The projected bonus multiplied income to date by
`months_in_quarter / months_elapsed` -- one month in, times three. That assumes
every month in a quarter carries an equal share of the target. None of them do.

On the live book it got two managers backwards at once:

| | Pace | Flat x3 | By pace |
|---|---|---|---|
| Michael Stewart | 91.5% — **behind** | 207,150 → **BONUS** | 176,660 → none |
| AnneM Goodchild | 115.8% — **ahead** | 62,565 → none | 74,877 → **BONUS** |

July is 39% of Michael's quarter and 28% of AnneM's. Tripling a month that large
overstates; tripling one that small understates. He was projected a bonus for a
month he missed, and she was projected none for a month she beat.

Neither figure was obviously wrong on the page. The only way to catch it was to
know that Michael had missed July and ask why he was being projected $6,651.

## The fix

Project by **pace**: the ratio of income to the target for the months that have
finished, applied to the whole quarter's target. A manager running at 91.5% is
projected to finish at 91.5% of target -- which is what anybody reading the number
would assume it already meant.

That carries the shape of the forecast with it, so an uneven quarter projects
correctly without anyone having to know it is uneven.

Two smaller things in the same change:

- The projection now rests on `actual_income_completed`, matching the pace figure
  beside it, so the two can never tell different stories.
- A projection with no completed month behind it is **null**, not zero. Without
  one it is not a projection, it is a guess.

## Verified

Replaying the live figures through the new expression:

```
Michael Stewart   91.5%  ->  176,660   no bonus
AnneM Goodchild  115.8%  ->   74,877   bonus $3,222.76
Liam Thornton    106.7%  ->  125,906   bonus $3,925.54
```

Bonus tests: 36 passed, 3 skipped.

## Install

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/versions/0023_project_by_pace.sql
```

Run the suite, restart the workflows, commit, push, publish.

**Check afterwards:** on the bonus tracker, Michael Stewart's projected bonus
should be nil and AnneM Goodchild's should be around $3,222. The projected-bonus
chart should show bars for the managers reading *ahead*, and nothing for those
reading *behind* -- which is not what it shows now.
